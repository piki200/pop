from django.shortcuts import redirect
from django.urls import reverse


class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        allowed_paths = [reverse("login"), reverse("register"), reverse("admin:index"), reverse("admin:login")]
        if not request.user.is_authenticated and request.path not in allowed_paths and not request.path.startswith("/admin/") and not request.path.startswith("/static/"):
            return redirect(f"{reverse('login')}?next={request.path}")

        if request.user.is_authenticated:
            role = getattr(request.user, "role", "admin")
            restricted = []

            if role == "parent":
                restricted = [
                    "employee_list", "employee_detail", "employee_create", "employee_update", "employee_delete",
                    "group_list", "group_detail", "group_create", "group_update", "group_delete",
                    "attendance_bulk", "schedule_create", "schedule_delete",
                    "lesson_create", "expense_list", "expense_create",
                    "reports",
                ]
            elif role == "teacher":
                restricted = [
                    "employee_create", "employee_update", "employee_delete",
                    "group_create", "group_update", "group_delete",
                    "schedule_create", "schedule_delete",
                    "expense_create", "reports",
                ]

            if restricted:
                current_url_name = None
                from django.urls import resolve
                try:
                    current_url_name = resolve(request.path).url_name
                except:
                    pass
                if current_url_name in restricted:
                    return redirect("dashboard")

        return self.get_response(request)
