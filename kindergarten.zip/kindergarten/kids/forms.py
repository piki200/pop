from django import forms
from .models import (
    Child, Employee, Group, GroupMembership,
    Attendance, Payment, Expense, Lesson, Schedule, MedicalRecord
)


class ChildForm(forms.ModelForm):
    class Meta:
        model = Child
        fields = [
            "first_name", "last_name", "middle_name", "date_of_birth",
            "gender", "address", "parent_name", "parent_phone",
            "parent_email", "parent_work", "enrollment_date",
            "medical_notes", "allergies", "is_active", "photo"
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "enrollment_date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "address": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "medical_notes": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "allergies": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "first_name": forms.TextInput(attrs={"class": "form-field"}),
            "last_name": forms.TextInput(attrs={"class": "form-field"}),
            "middle_name": forms.TextInput(attrs={"class": "form-field"}),
            "gender": forms.Select(attrs={"class": "form-field"}),
            "parent_name": forms.TextInput(attrs={"class": "form-field"}),
            "parent_phone": forms.TextInput(attrs={"class": "form-field"}),
            "parent_email": forms.EmailInput(attrs={"class": "form-field"}),
            "parent_work": forms.TextInput(attrs={"class": "form-field"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "photo": forms.FileInput(attrs={"class": "form-field"}),
        }


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = [
            "first_name", "last_name", "middle_name", "phone", "email",
            "position", "hire_date", "salary", "address", "is_active", "photo"
        ]
        widgets = {
            "hire_date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "address": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "first_name": forms.TextInput(attrs={"class": "form-field"}),
            "last_name": forms.TextInput(attrs={"class": "form-field"}),
            "middle_name": forms.TextInput(attrs={"class": "form-field"}),
            "phone": forms.TextInput(attrs={"class": "form-field"}),
            "email": forms.EmailInput(attrs={"class": "form-field"}),
            "position": forms.Select(attrs={"class": "form-field"}),
            "salary": forms.NumberInput(attrs={"class": "form-field"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "photo": forms.FileInput(attrs={"class": "form-field"}),
        }


class GroupForm(forms.ModelForm):
    class Meta:
        model = Group
        fields = ["name", "min_age", "max_age", "capacity", "description", "is_active"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "name": forms.TextInput(attrs={"class": "form-field"}),
            "min_age": forms.NumberInput(attrs={"class": "form-field"}),
            "max_age": forms.NumberInput(attrs={"class": "form-field"}),
            "capacity": forms.NumberInput(attrs={"class": "form-field"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }


class GroupMembershipForm(forms.ModelForm):
    class Meta:
        model = GroupMembership
        fields = ["child", "group", "date_from", "date_to", "notes"]
        widgets = {
            "date_from": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "date_to": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "notes": forms.Textarea(attrs={"rows": 2, "class": "form-field"}),
            "child": forms.Select(attrs={"class": "form-field"}),
            "group": forms.Select(attrs={"class": "form-field"}),
        }


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ["child", "date", "status", "check_in_time", "check_out_time", "temperature", "notes"]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "check_in_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "check_out_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "notes": forms.Textarea(attrs={"rows": 2, "class": "form-field"}),
            "child": forms.Select(attrs={"class": "form-field"}),
            "status": forms.Select(attrs={"class": "form-field"}),
            "temperature": forms.NumberInput(attrs={"class": "form-field", "step": "0.1"}),
        }


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = [
            "child", "amount", "payment_date", "payment_for_month",
            "payment_method", "status", "receipt_number", "notes"
        ]
        widgets = {
            "payment_date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "payment_for_month": forms.DateInput(attrs={"type": "month", "class": "form-field"}),
            "notes": forms.Textarea(attrs={"rows": 2, "class": "form-field"}),
            "child": forms.Select(attrs={"class": "form-field"}),
            "amount": forms.NumberInput(attrs={"class": "form-field"}),
            "payment_method": forms.Select(attrs={"class": "form-field"}),
            "status": forms.Select(attrs={"class": "form-field"}),
            "receipt_number": forms.TextInput(attrs={"class": "form-field"}),
        }


class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ["title", "amount", "expense_date", "category", "description"]
        widgets = {
            "expense_date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "description": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "title": forms.TextInput(attrs={"class": "form-field"}),
            "amount": forms.NumberInput(attrs={"class": "form-field"}),
            "category": forms.Select(attrs={"class": "form-field"}),
        }


class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ["group", "lesson_type", "schedule", "teacher", "date", "start_time", "end_time", "topic", "notes"]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "start_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "end_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "notes": forms.Textarea(attrs={"rows": 2, "class": "form-field"}),
            "group": forms.Select(attrs={"class": "form-field"}),
            "lesson_type": forms.Select(attrs={"class": "form-field"}),
            "schedule": forms.Select(attrs={"class": "form-field"}),
            "teacher": forms.Select(attrs={"class": "form-field"}),
            "topic": forms.TextInput(attrs={"class": "form-field"}),
        }


class ScheduleForm(forms.ModelForm):
    class Meta:
        model = Schedule
        fields = ["group", "lesson_type", "day_of_week", "start_time", "end_time", "teacher", "room"]
        widgets = {
            "start_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "end_time": forms.TimeInput(attrs={"type": "time", "class": "form-field"}),
            "group": forms.Select(attrs={"class": "form-field"}),
            "lesson_type": forms.Select(attrs={"class": "form-field"}),
            "day_of_week": forms.Select(attrs={"class": "form-field"}),
            "teacher": forms.Select(attrs={"class": "form-field"}),
            "room": forms.TextInput(attrs={"class": "form-field"}),
        }


class MedicalRecordForm(forms.ModelForm):
    class Meta:
        model = MedicalRecord
        fields = ["child", "record_date", "record_type", "description", "doctor_name"]
        widgets = {
            "record_date": forms.DateInput(attrs={"type": "date", "class": "form-field"}),
            "description": forms.Textarea(attrs={"rows": 3, "class": "form-field"}),
            "child": forms.Select(attrs={"class": "form-field"}),
            "record_type": forms.Select(attrs={"class": "form-field"}),
            "doctor_name": forms.TextInput(attrs={"class": "form-field"}),
        }


class AttendanceBulkForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date", "class": "form-field"}))
    group = forms.ModelChoiceField(
        queryset=Group.objects.filter(is_active=True),
        label="Группа",
        widget=forms.Select(attrs={"class": "form-field"})
    )


class ReportForm(forms.Form):
    REPORT_CHOICES = [
        ("attendance", "По посещаемости"),
        ("payments", "По платежам"),
        ("children", "По детям"),
        ("employees", "По сотрудникам"),
        ("groups", "По группам"),
        ("expenses", "По расходам"),
        ("debts", "Задолженности"),
    ]
    report_type = forms.ChoiceField(
        choices=REPORT_CHOICES,
        label="Тип отчёта",
        widget=forms.Select(attrs={"class": "form-field"})
    )
    date_from = forms.DateField(
        widget=forms.DateInput(attrs={"type": "date", "class": "form-field"}),
        label="Дата с"
    )
    date_to = forms.DateField(
        widget=forms.DateInput(attrs={"type": "date", "class": "form-field"}),
        label="Дата по"
    )
    group = forms.ModelChoiceField(
        queryset=Group.objects.filter(is_active=True),
        required=False,
        label="Группа",
        widget=forms.Select(attrs={"class": "form-field"})
    )
