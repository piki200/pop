import csv
from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.db.models import Count, Sum, Q
from django.utils import timezone
from django.contrib import messages
from django.core.paginator import Paginator
from datetime import date, timedelta
from .models import (
    User, Child, Employee, Group, GroupMembership, Attendance,
    LessonType, Schedule, Lesson, Payment, Expense, MedicalRecord
)
from .forms import (
    ChildForm, EmployeeForm, GroupForm, GroupMembershipForm,
    AttendanceForm, PaymentForm, ExpenseForm, LessonForm,
    ScheduleForm, MedicalRecordForm, ReportForm
)


def register(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name", "").strip()
        last_name = request.POST.get("last_name", "").strip()
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        phone = request.POST.get("phone", "").strip()
        password1 = request.POST.get("password1", "")
        password2 = request.POST.get("password2", "")

        if not username or not password1 or not first_name or not last_name:
            return render(request, "kids/register.html", {"error": "Заполните все обязательные поля."})
        if password1 != password2:
            return render(request, "kids/register.html", {"error": "Пароли не совпадают."})
        if len(password1) < 6:
            return render(request, "kids/register.html", {"error": "Пароль должен быть не менее 6 символов."})
        if User.objects.filter(username=username).exists():
            return render(request, "kids/register.html", {"error": "Пользователь с таким логином уже существует."})

        user = User.objects.create_user(
            username=username,
            password=password1,
            email=email,
            first_name=first_name,
            last_name=last_name,
            role="parent",
            phone=phone,
        )
        login(request, user)
        messages.success(request, "Регистрация прошла успешно.")
        return redirect("dashboard")

    return render(request, "kids/register.html")


def get_role_context(user):
    role = getattr(user, "role", "admin")
    employee = None
    child = None

    if role == "teacher":
        try:
            employee = Employee.objects.get(user=user)
        except Employee.DoesNotExist:
            pass
    elif role == "parent":
        try:
            child = Child.objects.get(parent_user=user)
        except Child.DoesNotExist:
            pass

    return {"role": role, "employee": employee, "child": child}


def get_teacher_groups(employee):
    if not employee:
        return Group.objects.none()
    return Group.objects.filter(
        Q(schedules__teacher=employee) | Q(memberships__child__in=Child.objects.filter(
            id__in=Attendance.objects.filter(marked_by=employee).values("child_id")
        ))
    ).distinct()


def filter_children_by_role(user, queryset=None):
    if queryset is None:
        queryset = Child.objects.all()
    role = getattr(user, "role", "admin")
    if role == "admin":
        return queryset
    if role == "teacher":
        try:
            employee = Employee.objects.get(user=user)
            groups = get_teacher_groups(employee)
            return queryset.filter(memberships__group__in=groups, memberships__date_to__isnull=True)
        except Employee.DoesNotExist:
            return Child.objects.none()
    if role == "parent":
        return queryset.filter(parent_user=user)
    return queryset


def dashboard(request):
    ctx = get_role_context(request.user)
    today = timezone.now().date()
    first_of_month = today.replace(day=1)
    role = ctx["role"]

    if role == "admin":
        total_children = Child.objects.filter(is_active=True).count()
        total_employees = Employee.objects.filter(is_active=True).count()
        total_groups = Group.objects.filter(is_active=True).count()
        attendance_qs = Attendance.objects.filter(date=today)
        monthly_payments = Payment.objects.filter(
            payment_date__gte=first_of_month, payment_date__lte=today, status="paid"
        ).aggregate(total=Sum("amount"))["total"] or 0
        monthly_expenses = Expense.objects.filter(
            expense_date__gte=first_of_month, expense_date__lte=today
        ).aggregate(total=Sum("amount"))["total"] or 0
        recent_payments = Payment.objects.filter(status="pending").select_related("child")[:10]
        groups_summary = Group.objects.filter(is_active=True).annotate(
            child_count=Count("memberships", filter=Q(memberships__date_to__isnull=True))
        )
        upcoming_birthdays = Child.objects.filter(
            is_active=True, date_of_birth__month=today.month,
            date_of_birth__day__gte=today.day
        ).order_by("date_of_birth__day")[:5]

    elif role == "teacher":
        employee = ctx["employee"]
        groups = get_teacher_groups(employee)
        children = Child.objects.filter(memberships__group__in=groups, memberships__date_to__isnull=True, is_active=True)
        total_children = children.count()
        total_employees = Employee.objects.filter(is_active=True).count()
        total_groups = groups.count()
        attendance_qs = Attendance.objects.filter(date=today, child__in=children)
        monthly_payments = Payment.objects.filter(
            child__in=children, payment_date__gte=first_of_month, payment_date__lte=today
        ).aggregate(total=Sum("amount"))["total"] or 0
        monthly_expenses = 0
        groups_summary = groups.annotate(
            child_count=Count("memberships", filter=Q(memberships__date_to__isnull=True))
        )
        upcoming_birthdays = children.filter(
            date_of_birth__month=today.month, date_of_birth__day__gte=today.day
        ).order_by("date_of_birth__day")[:5]
        recent_payments = Payment.objects.filter(
            child__in=children, status="pending"
        ).select_related("child")[:10]

    else:
        child = ctx["child"]
        children = Child.objects.filter(pk=child.pk) if child else Child.objects.none()
        total_children = children.count()
        total_employees = 0
        total_groups = 0
        attendance_qs = Attendance.objects.filter(date=today, child__in=children)
        monthly_payments = Payment.objects.filter(
            child__in=children, payment_date__gte=first_of_month, payment_date__lte=today
        ).aggregate(total=Sum("amount"))["total"] or 0
        monthly_expenses = 0
        groups_summary = Group.objects.filter(
            memberships__child__in=children, memberships__date_to__isnull=True
        ).annotate(child_count=Count("memberships", filter=Q(memberships__date_to__isnull=True)))
        upcoming_birthdays = children.filter(
            date_of_birth__month=today.month, date_of_birth__day__gte=today.day
        )[:5]
        recent_payments = Payment.objects.filter(child__in=children, status="pending")[:10]

    present_today = attendance_qs.filter(status="present").count()
    absent_today = attendance_qs.filter(status="absent").count()
    sick_today = attendance_qs.filter(status="sick").count()

    children_qs = children if role != "admin" else Child.objects.filter(is_active=True)
    week_days = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        day_qs = Attendance.objects.filter(date=d, child__in=children_qs)
        week_days.append({
            "label": d.strftime("%a"),
            "date": d.strftime("%d.%m"),
            "present": day_qs.filter(status="present").count(),
            "absent": day_qs.filter(status="absent").count(),
            "sick": day_qs.filter(status="sick").count(),
        })

    return render(request, "kids/dashboard.html", {
        **ctx,
        "total_children": total_children,
        "total_employees": total_employees,
        "total_groups": total_groups,
        "present_today": present_today,
        "absent_today": absent_today,
        "sick_today": sick_today,
        "monthly_payments": monthly_payments,
        "monthly_expenses": monthly_expenses,
        "upcoming_birthdays": upcoming_birthdays,
        "recent_payments": recent_payments,
        "groups_summary": groups_summary,
        "week_days": week_days,
    })


def child_list(request):
    ctx = get_role_context(request.user)
    children = filter_children_by_role(request.user).select_related()
    query = request.GET.get("q")
    group_filter = request.GET.get("group")

    if query:
        children = children.filter(
            Q(last_name__icontains=query) | Q(first_name__icontains=query) |
            Q(parent_phone__icontains=query) | Q(parent_name__icontains=query)
        )
    if group_filter:
        children = children.filter(memberships__group_id=group_filter, memberships__date_to__isnull=True)

    paginator = Paginator(children, 20)
    page = request.GET.get("page", 1)
    children_page = paginator.get_page(page)

    if ctx["role"] == "teacher":
        groups = get_teacher_groups(ctx["employee"])
    else:
        groups = Group.objects.filter(is_active=True)
    return render(request, "kids/child_list.html", {**ctx, "children": children_page, "groups": groups})


def child_export_excel(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    children = filter_children_by_role(request.user).select_related()
    query = request.GET.get("q")
    group_filter = request.GET.get("group")
    if query:
        children = children.filter(
            Q(last_name__icontains=query) | Q(first_name__icontains=query) |
            Q(parent_phone__icontains=query) | Q(parent_name__icontains=query)
        )
    if group_filter:
        children = children.filter(memberships__group_id=group_filter, memberships__date_to__isnull=True)

    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="children.csv"'
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(["Фамилия", "Имя", "Отчество", "Дата рождения", "Группа",
                      "Родитель", "Телефон", "Статус", "Адрес"])
    for child in children:
        membership = child.memberships.filter(date_to__isnull=True).first()
        group_name = membership.group.name if membership else ""
        status = "Активен" if child.is_active else "Отчислен"
        writer.writerow([
            child.last_name, child.first_name, child.middle_name,
            child.date_of_birth.strftime("%d.%m.%Y"),
            group_name, child.parent_name, child.parent_phone,
            status, child.address or ""
        ])
    return response


def child_detail(request, pk):
    ctx = get_role_context(request.user)
    allowed = filter_children_by_role(request.user)
    child = get_object_or_404(Child.objects.prefetch_related(
        "memberships__group", "attendances", "payments", "medical_records"
    ), pk=pk)
    if not allowed.filter(pk=pk).exists() and ctx["role"] != "admin":
        messages.error(request, "У вас нет доступа к этому ребёнку.")
        return redirect("dashboard")
    return render(request, "kids/child_detail.html", {**ctx, "child": child})


def child_create(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    if request.method == "POST":
        form = ChildForm(request.POST, request.FILES)
        if form.is_valid():
            child = form.save()
            messages.success(request, f"Ребёнок {child} добавлен.")
            return redirect("child_detail", pk=child.pk)
    else:
        form = ChildForm()
    return render(request, "kids/child_form.html", {
        **get_role_context(request.user), "form": form, "title": "Добавление ребёнка"
    })


def child_update(request, pk):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    child = get_object_or_404(Child, pk=pk)
    if request.method == "POST":
        form = ChildForm(request.POST, request.FILES, instance=child)
        if form.is_valid():
            form.save()
            messages.success(request, "Данные ребёнка обновлены.")
            return redirect("child_detail", pk=child.pk)
    else:
        form = ChildForm(instance=child)
    return render(request, "kids/child_form.html", {
        **get_role_context(request.user), "form": form, "title": "Редактирование ребёнка"
    })


def child_delete(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    child = get_object_or_404(Child, pk=pk)
    if request.method == "POST":
        child.delete()
        messages.success(request, "Ребёнок удалён.")
        return redirect("child_list")
    return render(request, "kids/child_confirm_delete.html", {
        **get_role_context(request.user), "child": child
    })


def employee_list(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    ctx = get_role_context(request.user)
    if request.user.role == "teacher":
        employees = Employee.objects.filter(position="teacher")
    else:
        employees = Employee.objects.all()
    position = request.GET.get("position")
    if position:
        employees = employees.filter(position=position)
    return render(request, "kids/employee_list.html", {
        **ctx, "employees": employees, "positions": Employee.POSITION_CHOICES
    })


def employee_detail(request, pk):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    ctx = get_role_context(request.user)
    employee = get_object_or_404(Employee, pk=pk)
    if request.user.role == "teacher" and employee.position != "teacher":
        return redirect("employee_list")
    schedules = Schedule.objects.filter(teacher=employee)
    return render(request, "kids/employee_detail.html", {
        **ctx, "employee": employee, "schedules": schedules
    })


def employee_create(request):
    if request.user.role != "admin":
        return redirect("dashboard")
    if request.method == "POST":
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            employee = form.save()
            messages.success(request, f"Сотрудник {employee} добавлен.")
            return redirect("employee_detail", pk=employee.pk)
    else:
        form = EmployeeForm()
    return render(request, "kids/employee_form.html", {
        **get_role_context(request.user), "form": form, "title": "Добавление сотрудника"
    })


def employee_update(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        form = EmployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            messages.success(request, "Данные сотрудника обновлены.")
            return redirect("employee_detail", pk=employee.pk)
    else:
        form = EmployeeForm(instance=employee)
    return render(request, "kids/employee_form.html", {
        **get_role_context(request.user), "form": form, "title": "Редактирование сотрудника"
    })


def employee_delete(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        employee.delete()
        messages.success(request, "Сотрудник удалён.")
        return redirect("employee_list")
    return render(request, "kids/employee_confirm_delete.html", {
        **get_role_context(request.user), "employee": employee
    })


def group_list(request):
    ctx = get_role_context(request.user)
    role = ctx["role"]
    if role == "parent":
        return redirect("dashboard")
    if role == "teacher" and ctx["employee"]:
        groups = get_teacher_groups(ctx["employee"]).annotate(
            child_count=Count("memberships", filter=Q(memberships__date_to__isnull=True))
        )
    else:
        groups = Group.objects.all().annotate(
            child_count=Count("memberships", filter=Q(memberships__date_to__isnull=True))
        )
    return render(request, "kids/group_list.html", {**ctx, "groups": groups})


def group_detail(request, pk):
    ctx = get_role_context(request.user)
    if ctx["role"] == "parent":
        return redirect("dashboard")
    if ctx["role"] == "teacher":
        teacher_groups = get_teacher_groups(ctx["employee"])
        if not teacher_groups.filter(pk=pk).exists():
            return redirect("group_list")
    group = get_object_or_404(Group, pk=pk)
    children = Child.objects.filter(memberships__group=group, memberships__date_to__isnull=True)
    schedules = Schedule.objects.filter(group=group).select_related("lesson_type", "teacher")
    return render(request, "kids/group_detail.html", {
        **ctx, "group": group, "children": children, "schedules": schedules
    })


def group_create(request):
    if request.user.role != "admin":
        return redirect("dashboard")
    if request.method == "POST":
        form = GroupForm(request.POST)
        if form.is_valid():
            group = form.save()
            messages.success(request, f"Группа {group.name} создана.")
            return redirect("group_detail", pk=group.pk)
    else:
        form = GroupForm()
    return render(request, "kids/group_form.html", {
        **get_role_context(request.user), "form": form, "title": "Создание группы"
    })


def group_update(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    group = get_object_or_404(Group, pk=pk)
    if request.method == "POST":
        form = GroupForm(request.POST, instance=group)
        if form.is_valid():
            form.save()
            messages.success(request, "Группа обновлена.")
            return redirect("group_detail", pk=group.pk)
    else:
        form = GroupForm(instance=group)
    return render(request, "kids/group_form.html", {
        **get_role_context(request.user), "form": form, "title": "Редактирование группы"
    })


def group_delete(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    group = get_object_or_404(Group, pk=pk)
    if request.method == "POST":
        group.delete()
        messages.success(request, "Группа удалена.")
        return redirect("group_list")
    return render(request, "kids/group_confirm_delete.html", {
        **get_role_context(request.user), "group": group
    })


def attendance_list(request):
    ctx = get_role_context(request.user)
    today = timezone.now().date()
    date_param = request.GET.get("date", today)
    try:
        selected_date = date.fromisoformat(date_param)
    except (ValueError, TypeError):
        selected_date = today

    attendances = Attendance.objects.filter(date=selected_date).select_related("child", "marked_by")
    attendances = attendances.filter(child__in=filter_children_by_role(request.user))

    group_param = request.GET.get("group")
    if group_param:
        attendances = attendances.filter(
            child__memberships__group_id=group_param, child__memberships__date_to__isnull=True
        )

    if ctx["role"] == "teacher":
        groups = get_teacher_groups(ctx["employee"])
    else:
        groups = Group.objects.filter(is_active=True)
    return render(request, "kids/attendance_list.html", {
        **ctx, "attendances": attendances, "selected_date": selected_date, "groups": groups
    })


def attendance_create(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    if request.method == "POST":
        form = AttendanceForm(request.POST)
        if form.is_valid():
            attendance = form.save()
            messages.success(request, "Запись посещаемости добавлена.")
            return redirect("attendance_list")
    else:
        form = AttendanceForm(initial={"date": timezone.now().date()})
    return render(request, "kids/attendance_form.html", {
        **get_role_context(request.user), "form": form, "title": "Отметить посещаемость"
    })


def attendance_bulk(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    ctx = get_role_context(request.user)
    group = None
    children_data = []
    selected_date = timezone.now().date()

    if request.method == "POST":
        if "select_group" in request.POST:
            group_id = request.POST.get("group")
            selected_date = request.POST.get("date", selected_date)
            group = get_object_or_404(Group, pk=group_id)
            children = Child.objects.filter(
                memberships__group=group, memberships__date_to__isnull=True, is_active=True
            )
            existing = {a.child_id: a for a in Attendance.objects.filter(date=selected_date, child__in=children)}
            children_data = [(c, existing.get(c.id)) for c in children]
        elif "save_attendance" in request.POST:
            selected_date = request.POST.get("date")
            group_id = request.POST.get("group_id")
            group = get_object_or_404(Group, pk=group_id)
            children = Child.objects.filter(
                memberships__group=group, memberships__date_to__isnull=True, is_active=True
            )
            for child in children:
                status = request.POST.get(f"status_{child.id}")
                check_in = request.POST.get(f"check_in_{child.id}") or None
                check_out = request.POST.get(f"check_out_{child.id}") or None
                temp = request.POST.get(f"temp_{child.id}") or None
                if status:
                    Attendance.objects.update_or_create(
                        child=child, date=selected_date,
                        defaults={"status": status, "check_in_time": check_in, "check_out_time": check_out, "temperature": temp}
                    )
            messages.success(request, f"Посещаемость на {selected_date} сохранена.")
            return redirect("attendance_list")
    else:
        raw_date = request.GET.get("date")
        if raw_date:
            from datetime import datetime
            try:
                initial_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
            except (ValueError, TypeError):
                initial_date = timezone.now().date()
        else:
            initial_date = timezone.now().date()
        group_id = request.GET.get("group")
        if group_id:
            group = get_object_or_404(Group, pk=group_id)
            children = Child.objects.filter(
                memberships__group=group, memberships__date_to__isnull=True, is_active=True
            )
            existing = {a.child_id: a for a in Attendance.objects.filter(date=initial_date, child__in=children)}
            children_data = [(c, existing.get(c.id)) for c in children]
        selected_date = initial_date

    if ctx["role"] == "teacher":
        groups = get_teacher_groups(ctx["employee"])
    else:
        groups = Group.objects.filter(is_active=True)
    return render(request, "kids/attendance_bulk.html", {
        **ctx, "group": group, "children_data": children_data, "groups": groups, "selected_date": selected_date
    })


def payment_list(request):
    ctx = get_role_context(request.user)
    payments = Payment.objects.all().select_related("child", "created_by")
    payments = payments.filter(child__in=filter_children_by_role(request.user))
    status = request.GET.get("status")
    date_from = request.GET.get("date_from")
    date_to = request.GET.get("date_to")
    if status:
        payments = payments.filter(status=status)
    if date_from:
        payments = payments.filter(payment_date__gte=date_from)
    if date_to:
        payments = payments.filter(payment_date__lte=date_to)
    paginator = Paginator(payments, 20)
    page = request.GET.get("page", 1)
    payments_page = paginator.get_page(page)
    return render(request, "kids/payment_list.html", {**ctx, "payments": payments_page})


def payment_create(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    if request.method == "POST":
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save()
            messages.success(request, "Платёж зарегистрирован.")
            return redirect("payment_list")
    else:
        form = PaymentForm(initial={"payment_date": timezone.now().date(), "status": "paid"})
    return render(request, "kids/payment_form.html", {
        **get_role_context(request.user), "form": form, "title": "Новый платёж"
    })


def payment_update(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    payment = get_object_or_404(Payment, pk=pk)
    if request.method == "POST":
        form = PaymentForm(request.POST, instance=payment)
        if form.is_valid():
            form.save()
            messages.success(request, "Платёж обновлён.")
            return redirect("payment_list")
    else:
        form = PaymentForm(instance=payment)
    return render(request, "kids/payment_form.html", {
        **get_role_context(request.user), "form": form, "title": "Редактирование платежа"
    })


def payment_delete(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    payment = get_object_or_404(Payment, pk=pk)
    if request.method == "POST":
        payment.delete()
        messages.success(request, "Платёж удалён.")
        return redirect("payment_list")
    return render(request, "kids/payment_confirm_delete.html", {
        **get_role_context(request.user), "payment": payment
    })


def expense_list(request):
    if request.user.role not in ("admin",):
        return redirect("dashboard")
    ctx = get_role_context(request.user)
    expenses = Expense.objects.all().select_related("created_by")
    category = request.GET.get("category")
    date_from = request.GET.get("date_from")
    date_to = request.GET.get("date_to")
    if category:
        expenses = expenses.filter(category=category)
    if date_from:
        expenses = expenses.filter(expense_date__gte=date_from)
    if date_to:
        expenses = expenses.filter(expense_date__lte=date_to)
    total = expenses.aggregate(total=Sum("amount"))["total"] or 0
    paginator = Paginator(expenses, 20)
    page = request.GET.get("page", 1)
    expenses_page = paginator.get_page(page)
    return render(request, "kids/expense_list.html", {
        **ctx, "expenses": expenses_page, "total": total, "categories": Expense.CATEGORY_CHOICES
    })


def expense_create(request):
    if request.user.role not in ("admin",):
        return redirect("dashboard")
    if request.method == "POST":
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save()
            messages.success(request, "Расход зарегистрирован.")
            return redirect("expense_list")
    else:
        form = ExpenseForm(initial={"expense_date": timezone.now().date()})
    return render(request, "kids/expense_form.html", {
        **get_role_context(request.user), "form": form, "title": "Новый расход"
    })


def schedule_list(request):
    ctx = get_role_context(request.user)
    if ctx["role"] == "parent":
        return redirect("dashboard")
    groups = Group.objects.filter(is_active=True)
    schedules = Schedule.objects.all().select_related("group", "lesson_type", "teacher")

    if ctx["role"] == "teacher" and ctx["employee"]:
        teacher_groups = get_teacher_groups(ctx["employee"])
        schedules = schedules.filter(group__in=teacher_groups)
        groups = teacher_groups

    group_filter = request.GET.get("group")
    day_filter = request.GET.get("day")
    if group_filter:
        schedules = schedules.filter(group_id=group_filter)
    if day_filter:
        schedules = schedules.filter(day_of_week=day_filter)

    return render(request, "kids/schedule_list.html", {
        **ctx, "schedules": schedules, "groups": groups, "days": Schedule.DAY_CHOICES
    })


def schedule_create(request):
    if request.user.role != "admin":
        return redirect("dashboard")
    if request.method == "POST":
        form = ScheduleForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Занятие в расписании добавлено.")
            return redirect("schedule_list")
    else:
        form = ScheduleForm()
    return render(request, "kids/schedule_form.html", {
        **get_role_context(request.user), "form": form, "title": "Добавление в расписание"
    })


def schedule_delete(request, pk):
    if request.user.role != "admin":
        return redirect("dashboard")
    schedule = get_object_or_404(Schedule, pk=pk)
    if request.method == "POST":
        schedule.delete()
        messages.success(request, "Занятие удалено из расписания.")
        return redirect("schedule_list")
    return render(request, "kids/schedule_confirm_delete.html", {
        **get_role_context(request.user), "schedule": schedule
    })


def lesson_list(request):
    ctx = get_role_context(request.user)
    lessons = Lesson.objects.all().select_related("group", "lesson_type", "teacher")

    if ctx["role"] == "teacher" and ctx["employee"]:
        teacher_groups = get_teacher_groups(ctx["employee"])
        lessons = lessons.filter(group__in=teacher_groups)

    if ctx["role"] == "parent" and ctx.get("child"):
        child_groups = GroupMembership.objects.filter(
            child=ctx["child"], date_to__isnull=True
        ).values_list("group", flat=True)
        lessons = lessons.filter(group__in=child_groups)

    group_filter = request.GET.get("group")
    if group_filter:
        lessons = lessons.filter(group_id=group_filter)
    return render(request, "kids/lesson_list.html", {**ctx, "lessons": lessons})


def lesson_create(request):
    if request.user.role not in ("admin", "teacher"):
        return redirect("dashboard")
    ctx = get_role_context(request.user)

    if ctx["role"] == "teacher":
        allowed_groups = get_teacher_groups(ctx["employee"])
    else:
        allowed_groups = Group.objects.filter(is_active=True)

    if request.method == "POST":
        form = LessonForm(request.POST)
        form.fields["group"].queryset = allowed_groups
        if form.is_valid():
            form.save()
            messages.success(request, "Занятие записано.")
            return redirect("lesson_list")
    else:
        form = LessonForm(initial={"date": timezone.now().date()})
        form.fields["group"].queryset = allowed_groups
    return render(request, "kids/lesson_form.html", {
        **ctx, "form": form, "title": "Запись занятия"
    })


def reports(request):
    if request.user.role != "admin":
        return redirect("dashboard")
    ctx = get_role_context(request.user)
    results = None
    report_form = ReportForm(request.GET or None)

    if report_form.is_valid():
        report_type = report_form.cleaned_data["report_type"]
        date_from = report_form.cleaned_data["date_from"]
        date_to = report_form.cleaned_data["date_to"]
        group = report_form.cleaned_data.get("group")

        if report_type == "attendance":
            qs = Attendance.objects.filter(date__gte=date_from, date__lte=date_to)
            if group:
                qs = qs.filter(child__memberships__group=group, child__memberships__date_to__isnull=True)
            total = qs.count()
            results = {
                "title": "Отчёт по посещаемости",
                "headers": ["Дата", "Ребёнок", "Статус", "Примечания"],
                "rows": [[a.date, str(a.child), a.get_status_display(), a.notes] for a in qs.select_related("child").order_by("date")[:200]],
                "summary": {"Всего записей": total, "Присутствовало": qs.filter(status="present").count(),
                            "Отсутствовало": qs.filter(status="absent").count(), "Болело": qs.filter(status="sick").count()}
            }
        elif report_type == "payments":
            qs = Payment.objects.filter(payment_date__gte=date_from, payment_date__lte=date_to)
            if group:
                qs = qs.filter(child__memberships__group=group, child__memberships__date_to__isnull=True)
            total_amount = qs.aggregate(t=Sum("amount"))["t"] or 0
            results = {
                "title": "Отчёт по платежам",
                "headers": ["Дата", "Ребёнок", "Сумма", "Статус", "Способ"],
                "rows": [[p.payment_date, str(p.child), f"{p.amount} руб.", p.get_status_display(), p.get_payment_method_display()] for p in qs.select_related("child").order_by("-payment_date")[:200]],
                "summary": {"Всего платежей": qs.count(), "На сумму": f"{total_amount} руб.", "Оплачено": qs.filter(status="paid").count(), "Просрочено": qs.filter(status="overdue").count()}
            }
        elif report_type == "children":
            qs = Child.objects.filter(enrollment_date__gte=date_from, enrollment_date__lte=date_to)
            if group:
                qs = qs.filter(memberships__group=group, memberships__date_to__isnull=True)
            results = {
                "title": "Отчёт по детям",
                "headers": ["ФИО", "Дата рождения", "Родитель", "Телефон", "Дата зачисления"],
                "rows": [[str(c), c.date_of_birth, c.parent_name, c.parent_phone, c.enrollment_date] for c in qs[:200]],
                "summary": {"Всего детей": qs.count()}
            }
        elif report_type == "employees":
            qs = Employee.objects.filter(hire_date__gte=date_from, hire_date__lte=date_to)
            results = {
                "title": "Отчёт по сотрудникам",
                "headers": ["ФИО", "Должность", "Телефон", "Дата приёма", "Зарплата"],
                "rows": [[str(e), e.get_position_display(), e.phone, e.hire_date, f"{e.salary} руб."] for e in qs[:200]],
                "summary": {"Всего сотрудников": qs.count()}
            }
        elif report_type == "groups":
            qs = Group.objects.all()
            results = {
                "title": "Отчёт по группам",
                "headers": ["Группа", "Возраст", "Вместимость", "Детей"],
                "rows": [[g.name, f"{g.min_age // 12}-{g.max_age // 12} лет", g.capacity, g.memberships.filter(date_to__isnull=True).count()] for g in qs],
                "summary": {"Всего групп": qs.count()}
            }
        elif report_type == "expenses":
            qs = Expense.objects.filter(expense_date__gte=date_from, expense_date__lte=date_to)
            total = qs.aggregate(t=Sum("amount"))["t"] or 0
            results = {
                "title": "Отчёт по расходам",
                "headers": ["Дата", "Наименование", "Категория", "Сумма"],
                "rows": [[e.expense_date, e.title, e.get_category_display(), f"{e.amount} руб."] for e in qs.order_by("-expense_date")[:200]],
                "summary": {"Всего расходов": qs.count(), "На сумму": f"{total} руб."}
            }
        elif report_type == "debts":
            last_month = timezone.now().date().replace(day=1) - timedelta(days=1)
            first_of_last = last_month.replace(day=1)
            paid_ids = Payment.objects.filter(payment_for_month__gte=first_of_last, payment_for_month__lte=last_month, status="paid").values_list("child_id", flat=True)
            debtors = Child.objects.filter(is_active=True).exclude(id__in=paid_ids)
            if group:
                debtors = debtors.filter(memberships__group=group, memberships__date_to__isnull=True)
            results = {
                "title": "Задолженности по оплате",
                "headers": ["ФИО ребёнка", "Группа", "Родитель", "Телефон"],
                "rows": [[str(d), d.current_group(), d.parent_name, d.parent_phone] for d in debtors[:200]],
                "summary": {"Должников": debtors.count()}
            }

    return render(request, "kids/reports.html", {
        **ctx, "form": report_form, "results": results, "groups": Group.objects.filter(is_active=True)
    })
