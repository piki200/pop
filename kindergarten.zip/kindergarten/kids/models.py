from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from decimal import Decimal


class User(AbstractUser):
    ROLE_CHOICES = [
        ("admin", "Администратор"),
        ("teacher", "Воспитатель"),
        ("parent", "Родитель"),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="admin", verbose_name="Роль")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Телефон")

    class Meta:
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"

    def is_admin_role(self):
        return self.role == "admin"

    def is_teacher_role(self):
        return self.role == "teacher"

    def is_parent_role(self):
        return self.role == "parent"


class Group(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название группы")
    min_age = models.IntegerField(verbose_name="Минимальный возраст (мес)")
    max_age = models.IntegerField(verbose_name="Максимальный возраст (мес)")
    capacity = models.IntegerField(verbose_name="Вместимость")
    description = models.TextField(blank=True, verbose_name="Описание")
    is_active = models.BooleanField(default=True, verbose_name="Активна")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Группа"
        verbose_name_plural = "Группы"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.min_age // 12}-{self.max_age // 12} лет)"


class Employee(models.Model):
    POSITION_CHOICES = [
        ("teacher", "Воспитатель"),
        ("assistant", "Помощник воспитателя"),
        ("director", "Заведующая"),
        ("methodist", "Методист"),
        ("psychologist", "Психолог"),
        ("nurse", "Медсестра"),
        ("cook", "Повар"),
        ("cleaner", "Уборщица"),
        ("guard", "Охранник"),
        ("admin", "Администратор"),
    ]

    user = models.OneToOneField(
        User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Пользователь"
    )
    first_name = models.CharField(max_length=100, verbose_name="Имя")
    last_name = models.CharField(max_length=100, verbose_name="Фамилия")
    middle_name = models.CharField(max_length=100, blank=True, verbose_name="Отчество")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(blank=True, verbose_name="Email")
    position = models.CharField(max_length=50, choices=POSITION_CHOICES, verbose_name="Должность")
    hire_date = models.DateField(verbose_name="Дата приёма")
    salary = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Зарплата")
    address = models.TextField(blank=True, verbose_name="Адрес")
    is_active = models.BooleanField(default=True, verbose_name="Активен")
    photo = models.ImageField(upload_to="employees/", blank=True, null=True, verbose_name="Фото")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Сотрудник"
        verbose_name_plural = "Сотрудники"
        ordering = ["last_name", "first_name"]

    def __str__(self):
        return f"{self.last_name} {self.first_name} {self.middle_name}"


class Child(models.Model):
    GENDER_CHOICES = [("M", "Мальчик"), ("F", "Девочка")]

    first_name = models.CharField(max_length=100, verbose_name="Имя")
    last_name = models.CharField(max_length=100, verbose_name="Фамилия")
    middle_name = models.CharField(max_length=100, blank=True, verbose_name="Отчество")
    date_of_birth = models.DateField(verbose_name="Дата рождения")
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, verbose_name="Пол")
    address = models.TextField(blank=True, verbose_name="Адрес")
    parent_name = models.CharField(max_length=200, verbose_name="ФИО родителя")
    parent_phone = models.CharField(max_length=20, verbose_name="Телефон родителя")
    parent_email = models.EmailField(blank=True, verbose_name="Email родителя")
    parent_work = models.CharField(max_length=200, blank=True, verbose_name="Место работы родителя")
    parent_user = models.OneToOneField(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="child", verbose_name="Учётная запись родителя"
    )
    enrollment_date = models.DateField(verbose_name="Дата зачисления")
    medical_notes = models.TextField(blank=True, verbose_name="Медицинские заметки")
    allergies = models.TextField(blank=True, verbose_name="Аллергии")
    is_active = models.BooleanField(default=True, verbose_name="Активен")
    photo = models.ImageField(upload_to="children/", blank=True, null=True, verbose_name="Фото")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Ребёнок"
        verbose_name_plural = "Дети"
        ordering = ["last_name", "first_name"]

    def __str__(self):
        return f"{self.last_name} {self.first_name} {self.middle_name}"

    def age_in_months(self):
        today = timezone.now().date()
        return (today.year - self.date_of_birth.year) * 12 + (today.month - self.date_of_birth.month)

    def current_group(self):
        membership = self.memberships.filter(date_to__isnull=True).first()
        return membership.group if membership else None


class GroupMembership(models.Model):
    child = models.ForeignKey(
        Child, on_delete=models.CASCADE, related_name="memberships", verbose_name="Ребёнок"
    )
    group = models.ForeignKey(
        Group, on_delete=models.CASCADE, related_name="memberships", verbose_name="Группа"
    )
    date_from = models.DateField(verbose_name="Дата зачисления")
    date_to = models.DateField(null=True, blank=True, verbose_name="Дата отчисления")
    notes = models.TextField(blank=True, verbose_name="Примечания")

    class Meta:
        verbose_name = "Состав группы"
        verbose_name_plural = "Состав групп"
        ordering = ["-date_from"]

    def __str__(self):
        return f"{self.child} -> {self.group}"


class Attendance(models.Model):
    STATUS_CHOICES = [
        ("present", "Присутствовал"),
        ("absent", "Отсутствовал"),
        ("sick", "Болеет"),
        ("vacation", "Отпуск"),
        ("late", "Опоздал"),
    ]

    child = models.ForeignKey(
        Child, on_delete=models.CASCADE, related_name="attendances", verbose_name="Ребёнок"
    )
    date = models.DateField(verbose_name="Дата")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, verbose_name="Статус")
    check_in_time = models.TimeField(null=True, blank=True, verbose_name="Время прихода")
    check_out_time = models.TimeField(null=True, blank=True, verbose_name="Время ухода")
    temperature = models.DecimalField(
        max_digits=4, decimal_places=1, null=True, blank=True, verbose_name="Температура"
    )
    notes = models.TextField(blank=True, verbose_name="Примечания")
    marked_by = models.ForeignKey(
        Employee, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Отметил"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Посещаемость"
        verbose_name_plural = "Посещаемость"
        ordering = ["-date", "child__last_name"]
        unique_together = ["child", "date"]

    def __str__(self):
        return f"{self.child} - {self.date} - {self.get_status_display()}"


class LessonType(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название занятия")
    description = models.TextField(blank=True, verbose_name="Описание")
    duration_minutes = models.IntegerField(verbose_name="Длительность (мин)")
    min_age = models.IntegerField(verbose_name="Минимальный возраст (мес)", default=0)
    max_age = models.IntegerField(verbose_name="Максимальный возраст (мес)", default=999)
    is_active = models.BooleanField(default=True, verbose_name="Активно")

    class Meta:
        verbose_name = "Тип занятия"
        verbose_name_plural = "Типы занятий"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Schedule(models.Model):
    DAY_CHOICES = [
        (1, "Понедельник"),
        (2, "Вторник"),
        (3, "Среда"),
        (4, "Четверг"),
        (5, "Пятница"),
        (6, "Суббота"),
        (7, "Воскресенье"),
    ]

    group = models.ForeignKey(
        Group, on_delete=models.CASCADE, related_name="schedules", verbose_name="Группа"
    )
    lesson_type = models.ForeignKey(
        LessonType, on_delete=models.CASCADE, related_name="schedules", verbose_name="Занятие"
    )
    day_of_week = models.IntegerField(choices=DAY_CHOICES, verbose_name="День недели")
    start_time = models.TimeField(verbose_name="Начало")
    end_time = models.TimeField(verbose_name="Конец")
    teacher = models.ForeignKey(
        Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name="schedules", verbose_name="Преподаватель"
    )
    room = models.CharField(max_length=50, blank=True, verbose_name="Кабинет")
    is_active = models.BooleanField(default=True, verbose_name="Активно")

    class Meta:
        verbose_name = "Расписание"
        verbose_name_plural = "Расписание"
        ordering = ["group", "day_of_week", "start_time"]

    def __str__(self):
        return f"{self.group} - {self.lesson_type} ({self.get_day_of_week_display()} {self.start_time})"


class Lesson(models.Model):
    group = models.ForeignKey(
        Group, on_delete=models.CASCADE, related_name="lessons", verbose_name="Группа"
    )
    lesson_type = models.ForeignKey(
        LessonType, on_delete=models.CASCADE, related_name="lessons", verbose_name="Занятие"
    )
    schedule = models.ForeignKey(
        Schedule, on_delete=models.SET_NULL, null=True, blank=True, related_name="lessons", verbose_name="По расписанию"
    )
    teacher = models.ForeignKey(
        Employee, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Преподаватель"
    )
    date = models.DateField(verbose_name="Дата")
    start_time = models.TimeField(verbose_name="Начало")
    end_time = models.TimeField(verbose_name="Конец")
    topic = models.CharField(max_length=200, blank=True, verbose_name="Тема")
    notes = models.TextField(blank=True, verbose_name="Заметки")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Проведённое занятие"
        verbose_name_plural = "Проведённые занятия"
        ordering = ["-date", "start_time"]

    def __str__(self):
        return f"{self.lesson_type} - {self.group} - {self.date}"


class Payment(models.Model):
    STATUS_CHOICES = [
        ("paid", "Оплачено"),
        ("pending", "Ожидает"),
        ("overdue", "Просрочено"),
        ("cancelled", "Отменено"),
    ]
    METHOD_CHOICES = [
        ("cash", "Наличные"),
        ("card", "Банковская карта"),
        ("transfer", "Банковский перевод"),
        ("online", "Онлайн"),
    ]

    child = models.ForeignKey(
        Child, on_delete=models.CASCADE, related_name="payments", verbose_name="Ребёнок"
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Сумма")
    payment_date = models.DateField(verbose_name="Дата платежа")
    payment_for_month = models.DateField(verbose_name="За месяц")
    payment_method = models.CharField(
        max_length=20, choices=METHOD_CHOICES, default="cash", verbose_name="Способ оплаты"
    )
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default="pending", verbose_name="Статус"
    )
    receipt_number = models.CharField(max_length=50, blank=True, verbose_name="Номер квитанции")
    notes = models.TextField(blank=True, verbose_name="Примечания")
    created_by = models.ForeignKey(
        Employee, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Принял"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Платёж"
        verbose_name_plural = "Платежи"
        ordering = ["-payment_date"]

    def __str__(self):
        return f"{self.child} - {self.amount} руб. - {self.payment_date}"


class Expense(models.Model):
    CATEGORY_CHOICES = [
        ("food", "Питание"),
        ("salary", "Зарплата"),
        ("utilities", "Коммунальные услуги"),
        ("repair", "Ремонт"),
        ("toys", "Игрушки и пособия"),
        ("furniture", "Мебель"),
        ("medical", "Медицина"),
        ("other", "Прочее"),
    ]

    title = models.CharField(max_length=200, verbose_name="Наименование")
    amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Сумма")
    expense_date = models.DateField(verbose_name="Дата расхода")
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, verbose_name="Категория")
    description = models.TextField(blank=True, verbose_name="Описание")
    created_by = models.ForeignKey(
        Employee, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Создал"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Расход"
        verbose_name_plural = "Расходы"
        ordering = ["-expense_date"]

    def __str__(self):
        return f"{self.title} - {self.amount} руб."


class MedicalRecord(models.Model):
    RECORD_CHOICES = [
        ("vaccination", "Прививка"),
        ("illness", "Заболевание"),
        ("allergy", "Аллергия"),
        ("examination", "Осмотр"),
        ("note", "Заметка"),
    ]

    child = models.ForeignKey(
        Child, on_delete=models.CASCADE, related_name="medical_records", verbose_name="Ребёнок"
    )
    record_date = models.DateField(verbose_name="Дата записи")
    record_type = models.CharField(
        max_length=30, choices=RECORD_CHOICES, verbose_name="Тип записи"
    )
    description = models.TextField(verbose_name="Описание")
    doctor_name = models.CharField(max_length=200, blank=True, verbose_name="Врач")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Медицинская запись"
        verbose_name_plural = "Медицинские записи"
        ordering = ["-record_date"]

    def __str__(self):
        return f"{self.child} - {self.get_record_type_display()} - {self.record_date}"
