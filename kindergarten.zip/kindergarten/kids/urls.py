from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("login/", auth_views.LoginView.as_view(template_name="kids/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(next_page="/login/"), name="logout"),
    path("register/", views.register, name="register"),

    path("", views.dashboard, name="dashboard"),

    path("children/", views.child_list, name="child_list"),
    path("children/export/", views.child_export_excel, name="child_export_excel"),
    path("children/<int:pk>/", views.child_detail, name="child_detail"),
    path("children/create/", views.child_create, name="child_create"),
    path("children/<int:pk>/edit/", views.child_update, name="child_update"),
    path("children/<int:pk>/delete/", views.child_delete, name="child_delete"),

    path("employees/", views.employee_list, name="employee_list"),
    path("employees/<int:pk>/", views.employee_detail, name="employee_detail"),
    path("employees/create/", views.employee_create, name="employee_create"),
    path("employees/<int:pk>/edit/", views.employee_update, name="employee_update"),
    path("employees/<int:pk>/delete/", views.employee_delete, name="employee_delete"),

    path("groups/", views.group_list, name="group_list"),
    path("groups/<int:pk>/", views.group_detail, name="group_detail"),
    path("groups/create/", views.group_create, name="group_create"),
    path("groups/<int:pk>/edit/", views.group_update, name="group_update"),
    path("groups/<int:pk>/delete/", views.group_delete, name="group_delete"),

    path("attendance/", views.attendance_list, name="attendance_list"),
    path("attendance/create/", views.attendance_create, name="attendance_create"),
    path("attendance/bulk/", views.attendance_bulk, name="attendance_bulk"),

    path("payments/", views.payment_list, name="payment_list"),
    path("payments/create/", views.payment_create, name="payment_create"),
    path("payments/<int:pk>/edit/", views.payment_update, name="payment_update"),
    path("payments/<int:pk>/delete/", views.payment_delete, name="payment_delete"),

    path("expenses/", views.expense_list, name="expense_list"),
    path("expenses/create/", views.expense_create, name="expense_create"),

    path("schedule/", views.schedule_list, name="schedule_list"),
    path("schedule/create/", views.schedule_create, name="schedule_create"),
    path("schedule/<int:pk>/delete/", views.schedule_delete, name="schedule_delete"),

    path("lessons/", views.lesson_list, name="lesson_list"),
    path("lessons/create/", views.lesson_create, name="lesson_create"),

    path("reports/", views.reports, name="reports"),
]
