from django.contrib import admin
from .models import (
    User, Group, Employee, Child, GroupMembership,
    Attendance, LessonType, Schedule, Lesson,
    Payment, Expense, MedicalRecord
)


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ["username", "email", "role", "is_staff"]
    list_filter = ["role", "is_staff"]


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ["name", "min_age", "max_age", "capacity", "is_active"]
    list_filter = ["is_active"]
    search_fields = ["name"]


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ["last_name", "first_name", "position", "phone", "is_active"]
    list_filter = ["position", "is_active"]
    search_fields = ["last_name", "first_name", "phone"]


@admin.register(Child)
class ChildAdmin(admin.ModelAdmin):
    list_display = ["last_name", "first_name", "date_of_birth", "gender", "is_active"]
    list_filter = ["gender", "is_active"]
    search_fields = ["last_name", "first_name", "parent_phone"]


@admin.register(GroupMembership)
class GroupMembershipAdmin(admin.ModelAdmin):
    list_display = ["child", "group", "date_from", "date_to"]
    list_filter = ["group"]
    search_fields = ["child__last_name", "child__first_name"]


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ["child", "date", "status", "check_in_time", "check_out_time"]
    list_filter = ["status", "date"]
    search_fields = ["child__last_name", "child__first_name"]
    date_hierarchy = "date"


@admin.register(LessonType)
class LessonTypeAdmin(admin.ModelAdmin):
    list_display = ["name", "duration_minutes", "min_age", "max_age", "is_active"]
    list_filter = ["is_active"]


@admin.register(Schedule)
class ScheduleAdmin(admin.ModelAdmin):
    list_display = ["group", "lesson_type", "day_of_week", "start_time", "end_time", "teacher"]
    list_filter = ["group", "day_of_week"]


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ["group", "lesson_type", "date", "start_time", "end_time", "teacher"]
    list_filter = ["group", "date"]
    date_hierarchy = "date"


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ["child", "amount", "payment_date", "payment_for_month", "status"]
    list_filter = ["status", "payment_method"]
    search_fields = ["child__last_name", "receipt_number"]


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ["title", "amount", "expense_date", "category"]
    list_filter = ["category"]
    date_hierarchy = "expense_date"


@admin.register(MedicalRecord)
class MedicalRecordAdmin(admin.ModelAdmin):
    list_display = ["child", "record_date", "record_type", "doctor_name"]
    list_filter = ["record_type"]
    search_fields = ["child__last_name", "doctor_name"]
