from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import date, time
from kids.models import (
    User, Group, Employee, Child, GroupMembership,
    Attendance, LessonType, Schedule, Lesson,
    Payment, Expense, MedicalRecord
)
from decimal import Decimal


class Command(BaseCommand):
    help = "Загружает тестовые данные для детского сада"

    def handle(self, *args, **options):
        self.stdout.write("Загрузка тестовых данных...")

        if Child.objects.exists():
            self.stdout.write("Данные уже загружены. Пропускаем.")
            return

        now = timezone.now()

        admin = User.objects.create_superuser(
            username="admin",
            email="admin@raduga.ru",
            password="admin123",
            role="admin",
            phone="+7(999)999-99-99",
        )
        admin.first_name = "Администратор"
        admin.last_name = "Системы"
        admin.save()

        teacher_user = User.objects.create_user(
            username="teacher", password="teacher123",
            role="teacher", phone="+7(903)333-33-33",
            first_name="Мария", last_name="Кузнецова", email="maria@raduga.ru"
        )

        self.teacher_user = teacher_user

        parent_user = User.objects.create_user(
            username="parent", password="parent123",
            role="parent", phone="+7(911)111-11-11",
            first_name="Алексей", last_name="Петров", email="alexey@mail.ru"
        )

        self.parent_user = parent_user

        groups_data = [
            Group(name="Ясельная", min_age=12, max_age=24, capacity=12,
                  description="Группа для самых маленьких (1-2 года)"),
            Group(name="Младшая", min_age=24, max_age=36, capacity=15,
                  description="Младшая группа (2-3 года)"),
            Group(name="Средняя", min_age=36, max_age=60, capacity=18,
                  description="Средняя группа (3-5 лет)"),
            Group(name="Старшая", min_age=60, max_age=84, capacity=18,
                  description="Старшая группа (5-7 лет)"),
            Group(name="Подготовительная", min_age=72, max_age=84, capacity=15,
                  description="Подготовка к школе (6-7 лет)"),
        ]
        Group.objects.bulk_create(groups_data)
        groups = {g.name: g for g in Group.objects.all()}

        employees_data = [
            Employee(first_name="Елена", last_name="Иванова", middle_name="Петровна",
                     phone="+7(901)111-11-11", email="elena@raduga.ru",
                     position="director", hire_date=date(2020, 1, 15),
                     salary=Decimal("85000.00"), address="г. Москва, ул. Садовая, д.1"),
            Employee(first_name="Ольга", last_name="Смирнова", middle_name="Алексеевна",
                     phone="+7(902)222-22-22", email="olga@raduga.ru",
                     position="methodist", hire_date=date(2020, 2, 1),
                     salary=Decimal("65000.00"), address="г. Москва, ул. Цветочная, д.5"),
            Employee(first_name="Мария", last_name="Кузнецова", middle_name="Сергеевна",
                     phone="+7(903)333-33-33", email="maria@raduga.ru",
                     position="teacher", hire_date=date(2021, 3, 1),
                     salary=Decimal("55000.00"), address="г. Москва, ул. Лесная, д.10"),
            Employee(first_name="Анна", last_name="Попова", middle_name="Дмитриевна",
                     phone="+7(904)444-44-44", email="anna@raduga.ru",
                     position="teacher", hire_date=date(2021, 4, 1),
                     salary=Decimal("55000.00"), address="г. Москва, ул. Парковая, д.3"),
            Employee(first_name="Наталья", last_name="Васильева", middle_name="Игоревна",
                     phone="+7(905)555-55-55", email="natalia@raduga.ru",
                     position="assistant", hire_date=date(2022, 1, 10),
                     salary=Decimal("35000.00"), address="г. Москва, ул. Новая, д.7"),
            Employee(first_name="Ирина", last_name="Морозова", middle_name="Викторовна",
                     phone="+7(906)666-66-66", email="irina@raduga.ru",
                     position="psychologist", hire_date=date(2021, 9, 1),
                     salary=Decimal("60000.00"), address="г. Москва, ул. Солнечная, д.12"),
            Employee(first_name="Татьяна", last_name="Волкова", middle_name="Андреевна",
                     phone="+7(907)777-77-77", email="tatiana@raduga.ru",
                     position="nurse", hire_date=date(2020, 6, 1),
                     salary=Decimal("50000.00"), address="г. Москва, ул. Речная, д.8"),
            Employee(first_name="Светлана", last_name="Зайцева", middle_name="Павловна",
                     phone="+7(908)888-88-88", email="svetlana@raduga.ru",
                     position="cook", hire_date=date(2020, 3, 1),
                     salary=Decimal("40000.00"), address="г. Москва, ул. Зелёная, д.15"),
            Employee(first_name="Екатерина", last_name="Белова", middle_name="Николаевна",
                     phone="+7(909)999-99-99", email="ekaterina@raduga.ru",
                     position="teacher", hire_date=date(2022, 9, 1),
                     salary=Decimal("50000.00"), address="г. Москва, ул. Широкая, д.20"),
            Employee(first_name="Дмитрий", last_name="Соколов", middle_name="Олегович",
                     phone="+7(910)000-00-00", email="dmitry@raduga.ru",
                     position="guard", hire_date=date(2023, 1, 15),
                     salary=Decimal("30000.00"), address="г. Москва, ул. Дальняя, д.1"),
        ]
        Employee.objects.bulk_create(employees_data)
        employees = list(Employee.objects.all())
        emp = {e.last_name: e for e in employees}

        children_data = [
            Child(first_name="Иван", last_name="Петров", middle_name="Алексеевич",
                  date_of_birth=date(2022, 3, 15), gender="M",
                  address="г. Москва, ул. Садовая, д.1",
                  parent_name="Петров Алексей Иванович", parent_phone="+7(911)111-11-11",
                  parent_email="alexey@mail.ru", parent_work="ООО Ромашка",
                  enrollment_date=date(2023, 9, 1)),
            Child(first_name="Мария", last_name="Сидорова", middle_name="Ивановна",
                  date_of_birth=date(2021, 8, 22), gender="F",
                  address="г. Москва, ул. Цветочная, д.5",
                  parent_name="Сидорова Елена Павловна", parent_phone="+7(912)222-22-22",
                  parent_email="elena@mail.ru", parent_work="Бухгалтерия №1",
                  enrollment_date=date(2023, 9, 1),
                  medical_notes="Наблюдение у аллерголога", allergies="Пыльца берёзы"),
            Child(first_name="Артём", last_name="Козлов", middle_name="Дмитриевич",
                  date_of_birth=date(2020, 5, 10), gender="M",
                  address="г. Москва, ул. Лесная, д.10",
                  parent_name="Козлов Дмитрий Сергеевич", parent_phone="+7(913)333-33-33",
                  parent_email="dmitry.kozlov@mail.ru", parent_work="Сбербанк",
                  enrollment_date=date(2022, 9, 1)),
            Child(first_name="София", last_name="Новикова", middle_name="Андреевна",
                  date_of_birth=date(2019, 11, 28), gender="F",
                  address="г. Москва, ул. Парковая, д.3",
                  parent_name="Новикова Ольга Викторовна", parent_phone="+7(914)444-44-44",
                  parent_email="olga.novikova@mail.ru", parent_work="Гимназия №5",
                  enrollment_date=date(2022, 9, 1)),
            Child(first_name="Максим", last_name="Фёдоров", middle_name="Антонович",
                  date_of_birth=date(2023, 1, 5), gender="M",
                  address="г. Москва, ул. Новая, д.7",
                  parent_name="Фёдоров Антон Павлович", parent_phone="+7(915)555-55-55",
                  parent_email="anton@mail.ru", parent_work="ИТ-Компания",
                  enrollment_date=date(2024, 1, 15)),
            Child(first_name="Алиса", last_name="Морозова", middle_name="Владимировна",
                  date_of_birth=date(2022, 7, 14), gender="F",
                  address="г. Москва, ул. Солнечная, д.12",
                  parent_name="Морозова Екатерина Андреевна", parent_phone="+7(916)666-66-66",
                  parent_email="ekaterina.m@mail.ru", parent_work="Домохозяйка",
                  enrollment_date=date(2023, 9, 1),
                  allergies="Лактоза"),
            Child(first_name="Даниил", last_name="Григорьев", middle_name="Павлович",
                  date_of_birth=date(2020, 12, 3), gender="M",
                  address="г. Москва, ул. Речная, д.8",
                  parent_name="Григорьев Павел Сергеевич", parent_phone="+7(917)777-77-77",
                  parent_email="pavel.g@mail.ru", parent_work="Автосервис",
                  enrollment_date=date(2022, 9, 1)),
            Child(first_name="Виктория", last_name="Павлова", middle_name="Денисовна",
                  date_of_birth=date(2019, 4, 18), gender="F",
                  address="г. Москва, ул. Зелёная, д.15",
                  parent_name="Павлова Анна Михайловна", parent_phone="+7(918)888-88-88",
                  parent_email="anna.pavlova@mail.ru", parent_work="Поликлиника №3",
                  enrollment_date=date(2021, 9, 1)),
            Child(first_name="Тимофей", last_name="Александров", middle_name="Романович",
                  date_of_birth=date(2022, 9, 20), gender="M",
                  address="г. Москва, ул. Широкая, д.20",
                  parent_name="Александров Роман Игоревич", parent_phone="+7(919)999-99-99",
                  parent_email="roman.a@mail.ru", parent_work="ООО СтройГарант",
                  enrollment_date=date(2024, 2, 1)),
            Child(first_name="Ева", last_name="Крылова", middle_name="Максимовна",
                  date_of_birth=date(2021, 6, 12), gender="F",
                  address="г. Москва, ул. Дальняя, д.1",
                  parent_name="Крылова Наталья Сергеевна", parent_phone="+7(920)000-00-00",
                  parent_email="natalia.k@mail.ru", parent_work="Школа №7",
                  enrollment_date=date(2023, 9, 1),
                  allergies="Клубника"),
            Child(first_name="Михаил", last_name="Тарасов", middle_name="Олегович",
                  date_of_birth=date(2020, 10, 30), gender="M",
                  address="г. Москва, ул. Садовая, д.15",
                  parent_name="Тарасов Олег Владимирович", parent_phone="+7(921)111-11-11",
                  parent_email="oleg.t@mail.ru", parent_work="Такси",
                  enrollment_date=date(2023, 1, 15)),
            Child(first_name="Арина", last_name="Беляева", middle_name="Станиславовна",
                  date_of_birth=date(2019, 2, 14), gender="F",
                  address="г. Москва, ул. Цветочная, д.8",
                  parent_name="Беляева Ирина Дмитриевна", parent_phone="+7(922)222-22-22",
                  parent_email="irina.b@mail.ru", parent_work="Банк ВТБ",
                  enrollment_date=date(2022, 9, 1)),
        ]
        Child.objects.bulk_create(children_data)
        children = list(Child.objects.all())

        maria_employee = emp["Кузнецова"]
        maria_employee.user = self.teacher_user
        maria_employee.save()

        ivan_child = children[0]
        ivan_child.parent_user = self.parent_user
        ivan_child.save()

        memberships = [
            GroupMembership(child=children[4], group=groups["Ясельная"], date_from=date(2024, 1, 15)),
            GroupMembership(child=children[8], group=groups["Ясельная"], date_from=date(2024, 2, 1)),
            GroupMembership(child=children[1], group=groups["Младшая"], date_from=date(2023, 9, 1)),
            GroupMembership(child=children[5], group=groups["Младшая"], date_from=date(2023, 9, 1)),
            GroupMembership(child=children[9], group=groups["Младшая"], date_from=date(2023, 9, 1)),
            GroupMembership(child=children[0], group=groups["Средняя"], date_from=date(2023, 9, 1)),
            GroupMembership(child=children[2], group=groups["Средняя"], date_from=date(2022, 9, 1)),
            GroupMembership(child=children[6], group=groups["Средняя"], date_from=date(2022, 9, 1)),
            GroupMembership(child=children[10], group=groups["Средняя"], date_from=date(2023, 1, 15)),
            GroupMembership(child=children[3], group=groups["Старшая"], date_from=date(2022, 9, 1)),
            GroupMembership(child=children[7], group=groups["Старшая"], date_from=date(2021, 9, 1)),
            GroupMembership(child=children[11], group=groups["Старшая"], date_from=date(2022, 9, 1)),
        ]
        GroupMembership.objects.bulk_create(memberships)

        lessons_data = [
            LessonType(name="Рисование", description="Занятия изобразительным искусством", duration_minutes=30, min_age=24, max_age=84),
            LessonType(name="Лепка", description="Лепка из пластилина и глины", duration_minutes=30, min_age=24, max_age=84),
            LessonType(name="Физкультура", description="Физические упражнения и игры", duration_minutes=30, min_age=12, max_age=84),
            LessonType(name="Музыка", description="Музыкальные занятия и пение", duration_minutes=30, min_age=12, max_age=84),
            LessonType(name="Развитие речи", description="Занятия по развитию речи", duration_minutes=30, min_age=24, max_age=84),
            LessonType(name="Математика", description="Основы математики и счёта", duration_minutes=30, min_age=36, max_age=84),
            LessonType(name="Английский язык", description="Изучение английского языка", duration_minutes=25, min_age=48, max_age=84),
            LessonType(name="Чтение", description="Обучение чтению", duration_minutes=30, min_age=60, max_age=84),
            LessonType(name="Окружающий мир", description="Изучение окружающего мира", duration_minutes=30, min_age=36, max_age=84),
            LessonType(name="Танцы", description="Хореография и ритмика", duration_minutes=30, min_age=36, max_age=84),
        ]
        LessonType.objects.bulk_create(lessons_data)
        lt = {lt.name: lt for lt in LessonType.objects.all()}

        maria_teacher = emp["Кузнецова"]
        anna_teacher = emp["Попова"]
        middle_group = groups["Средняя"]

        schedule_items = [
            Schedule(group=middle_group, lesson_type=lt["Рисование"], day_of_week=1,
                     start_time=time(9, 0), end_time=time(9, 30), teacher=maria_teacher, room="Каб. рисования"),
            Schedule(group=middle_group, lesson_type=lt["Музыка"], day_of_week=1,
                     start_time=time(10, 0), end_time=time(10, 30), teacher=anna_teacher, room="Муз. зал"),
            Schedule(group=middle_group, lesson_type=lt["Физкультура"], day_of_week=2,
                     start_time=time(9, 0), end_time=time(9, 30), teacher=maria_teacher, room="Спортзал"),
            Schedule(group=middle_group, lesson_type=lt["Развитие речи"], day_of_week=2,
                     start_time=time(10, 0), end_time=time(10, 30), teacher=anna_teacher, room="Каб. 3"),
            Schedule(group=middle_group, lesson_type=lt["Лепка"], day_of_week=3,
                     start_time=time(9, 0), end_time=time(9, 30), teacher=maria_teacher, room="Каб. 3"),
            Schedule(group=middle_group, lesson_type=lt["Математика"], day_of_week=3,
                     start_time=time(10, 0), end_time=time(10, 30), teacher=anna_teacher, room="Каб. 3"),
            Schedule(group=middle_group, lesson_type=lt["Музыка"], day_of_week=4,
                     start_time=time(9, 0), end_time=time(9, 30), teacher=anna_teacher, room="Муз. зал"),
            Schedule(group=middle_group, lesson_type=lt["Окружающий мир"], day_of_week=4,
                     start_time=time(10, 0), end_time=time(10, 30), teacher=maria_teacher, room="Каб. 3"),
            Schedule(group=middle_group, lesson_type=lt["Физкультура"], day_of_week=5,
                     start_time=time(9, 0), end_time=time(9, 30), teacher=maria_teacher, room="Спортзал"),
            Schedule(group=middle_group, lesson_type=lt["Рисование"], day_of_week=5,
                     start_time=time(10, 0), end_time=time(10, 30), teacher=anna_teacher, room="Каб. рисования"),
        ]
        Schedule.objects.bulk_create(schedule_items)
        schedules = list(Schedule.objects.all())

        lessons = [
            Lesson(group=middle_group, lesson_type=lt["Рисование"], schedule=schedules[0],
                   teacher=maria_teacher, date=date(2025, 5, 19),
                   start_time=time(9, 0), end_time=time(9, 30), topic="Весенние цветы"),
            Lesson(group=middle_group, lesson_type=lt["Музыка"], schedule=schedules[1],
                   teacher=anna_teacher, date=date(2025, 5, 19),
                   start_time=time(10, 0), end_time=time(10, 30), topic="Песни о весне"),
            Lesson(group=middle_group, lesson_type=lt["Физкультура"], schedule=schedules[2],
                   teacher=maria_teacher, date=date(2025, 5, 13),
                   start_time=time(9, 0), end_time=time(9, 30), topic="Эстафеты"),
            Lesson(group=middle_group, lesson_type=lt["Развитие речи"], schedule=schedules[3],
                   teacher=anna_teacher, date=date(2025, 5, 13),
                   start_time=time(10, 0), end_time=time(10, 30), topic="Времена года"),
        ]
        Lesson.objects.bulk_create(lessons)

        director = emp["Иванова"]

        payments = [
            Payment(child=children[0], amount=Decimal("35000"), payment_date=date(2025, 5, 1),
                    payment_for_month=date(2025, 5, 1), payment_method="card", status="paid",
                    receipt_number="REC-2025-001", created_by=director),
            Payment(child=children[1], amount=Decimal("35000"), payment_date=date(2025, 4, 28),
                    payment_for_month=date(2025, 5, 1), payment_method="cash", status="paid",
                    receipt_number="REC-2025-002", created_by=director),
            Payment(child=children[2], amount=Decimal("35000"), payment_date=date(2025, 5, 5),
                    payment_for_month=date(2025, 5, 1), payment_method="transfer", status="paid",
                    receipt_number="REC-2025-003", created_by=director),
            Payment(child=children[3], amount=Decimal("35000"), payment_date=date(2025, 5, 1),
                    payment_for_month=date(2025, 5, 1), payment_method="online", status="paid",
                    receipt_number="REC-2025-004", created_by=director),
            Payment(child=children[4], amount=Decimal("40000"), payment_date=date(2025, 5, 2),
                    payment_for_month=date(2025, 5, 1), payment_method="card", status="paid",
                    receipt_number="REC-2025-005", created_by=director),
            Payment(child=children[5], amount=Decimal("35000"), payment_date=date(2025, 4, 25),
                    payment_for_month=date(2025, 5, 1), payment_method="cash", status="paid",
                    receipt_number="REC-2025-006", notes="Оплачено досрочно", created_by=director),
            Payment(child=children[6], amount=Decimal("35000"), payment_date=date(2025, 5, 10),
                    payment_for_month=date(2025, 5, 1), payment_method="card", status="pending",
                    notes="Ожидает подтверждения", created_by=director),
            Payment(child=children[7], amount=Decimal("35000"), payment_date=date(2025, 5, 1),
                    payment_for_month=date(2025, 5, 1), payment_method="online", status="paid",
                    receipt_number="REC-2025-007", created_by=director),
            Payment(child=children[8], amount=Decimal("40000"), payment_date=date(2025, 5, 1),
                    payment_for_month=date(2025, 5, 1), payment_method="card", status="paid",
                    receipt_number="REC-2025-008", created_by=director),
            Payment(child=children[9], amount=Decimal("35000"), payment_date=date(2025, 5, 3),
                    payment_for_month=date(2025, 5, 1), payment_method="cash", status="paid",
                    receipt_number="REC-2025-009", created_by=director),
            Payment(child=children[10], amount=Decimal("35000"), payment_date=date(2025, 4, 15),
                    payment_for_month=date(2025, 5, 1), payment_method="transfer", status="paid",
                    receipt_number="REC-2025-010", created_by=director),
            Payment(child=children[11], amount=Decimal("35000"), payment_date=date(2025, 5, 5),
                    payment_for_month=date(2025, 5, 1), payment_method="card", status="pending",
                    notes="Ожидает", created_by=director),
        ]
        Payment.objects.bulk_create(payments)

        expenses = [
            Expense(title="Закупка продуктов", amount=Decimal("15000"), expense_date=date(2025, 5, 5),
                    category="food", description="Продукты на неделю", created_by=director),
            Expense(title="Зарплата мая", amount=Decimal("470000"), expense_date=date(2025, 5, 10),
                    category="salary", description="Зарплата сотрудникам за май", created_by=director),
            Expense(title="Электроэнергия", amount=Decimal("8500"), expense_date=date(2025, 5, 12),
                    category="utilities", description="Квитанция за апрель", created_by=director),
            Expense(title="Новые игрушки", amount=Decimal("12000"), expense_date=date(2025, 5, 8),
                    category="toys", description="Конструкторы и куклы", created_by=director),
            Expense(title="Канцтовары", amount=Decimal("3400"), expense_date=date(2025, 5, 6),
                    category="other", description="Бумага, краски, карандаши", created_by=director),
            Expense(title="Ремонт крана", amount=Decimal("2500"), expense_date=date(2025, 5, 4),
                    category="repair", description="Замена смесителя в ясельной группе", created_by=director),
        ]
        Expense.objects.bulk_create(expenses)

        nurse = emp["Волкова"]

        medical = [
            MedicalRecord(child=children[1], record_date=date(2024, 9, 15), record_type="allergy",
                          description="Выявлена аллергия на пыльцу берёзы", doctor_name="Петрова А.И."),
            MedicalRecord(child=children[5], record_date=date(2024, 10, 1), record_type="allergy",
                          description="Аллергия на лактозу, назначена диета", doctor_name="Петрова А.И."),
            MedicalRecord(child=children[1], record_date=date(2024, 11, 20), record_type="vaccination",
                          description="Прививка АКДС", doctor_name="Иванова М.С."),
            MedicalRecord(child=children[0], record_date=date(2025, 1, 15), record_type="examination",
                          description="Плановый осмотр, здоров", doctor_name="Петрова А.И."),
            MedicalRecord(child=children[2], record_date=date(2024, 12, 10), record_type="illness",
                          description="ОРВИ, лёгкая форма", doctor_name="Иванова М.С."),
            MedicalRecord(child=children[9], record_date=date(2025, 3, 1), record_type="allergy",
                          description="Аллергия на клубнику", doctor_name="Петрова А.И."),
        ]
        MedicalRecord.objects.bulk_create(medical)

        self.stdout.write(self.style.SUCCESS(
            f"Тестовые данные загружены:\n"
            f"  Пользователей: 1 (admin / admin123)\n"
            f"  Групп: {Group.objects.count()}\n"
            f"  Сотрудников: {Employee.objects.count()}\n"
            f"  Детей: {Child.objects.count()}\n"
            f"  Занятий: {LessonType.objects.count()}\n"
            f"  Платежей: {Payment.objects.count()}\n"
            f"  Расходов: {Expense.objects.count()}\n"
            f"  Мед. записей: {MedicalRecord.objects.count()}"
        ))
