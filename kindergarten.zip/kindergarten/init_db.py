"""
Скрипт инициализации базы данных.

Использование:
    python init_db.py

Создаёт базу данных MySQL и заполняет её тестовыми данными.
Требуется MySQL сервер с доступом root без пароля (или настройки ниже).
"""

import subprocess
import os

DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "kindergarten_db",
}

SQL_FILE = os.path.join(os.path.dirname(__file__), "database", "schema.sql")


def init_database():
    if not os.path.exists(SQL_FILE):
        print(f"SQL файл не найден: {SQL_FILE}")
        return False

    cmd = [
        "mysql",
        f"-h{DB_CONFIG['host']}",
        f"-u{DB_CONFIG['user']}",
    ]
    if DB_CONFIG["password"]:
        cmd.append(f"-p{DB_CONFIG['password']}")

    try:
        with open(SQL_FILE, "r", encoding="utf-8") as f:
            sql_content = f.read()

        result = subprocess.run(
            cmd,
            input=sql_content,
            text=True,
            capture_output=True,
            timeout=30,
        )

        if result.returncode == 0:
            print("База данных успешно инициализирована!")
            print(f"  БД: {DB_CONFIG['database']}")
            print(f"  Файл: {SQL_FILE}")
            return True
        else:
            print(f"Ошибка при выполнении SQL:")
            print(result.stderr)
            return False
    except FileNotFoundError:
        print("MySQL клиент (mysql) не найден. Убедитесь, что MySQL установлен.")
        print("Вы можете запустить SQL файл вручную через любой MySQL клиент.")
        return False
    except subprocess.TimeoutExpired:
        print("Превышено время ожидания MySQL.")
        return False


if __name__ == "__main__":
    print("Инициализация базы данных детского сада...")
    init_database()
