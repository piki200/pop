-- ============================================================
-- ИНФОРМАЦИОННАЯ СИСТЕМА ЧАСТНОГО ДЕТСКОГО САДА
-- Схема базы данных MySQL + тестовые данные
-- ============================================================

CREATE DATABASE IF NOT EXISTS kindergarten_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE kindergarten_db;

-- -----------------------------------------------------------
-- 1. ПОЛЬЗОВАТЕЛИ (auth_user — стандартная таблица Django)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    password VARCHAR(128) NOT NULL,
    last_login DATETIME(6) NULL,
    is_superuser TINYINT(1) NOT NULL DEFAULT 0,
    username VARCHAR(150) NOT NULL UNIQUE,
    first_name VARCHAR(150) NOT NULL DEFAULT '',
    last_name VARCHAR(150) NOT NULL DEFAULT '',
    email VARCHAR(254) NOT NULL DEFAULT '',
    is_staff TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    date_joined DATETIME(6) NOT NULL,
    is_employee TINYINT(1) NOT NULL DEFAULT 0,
    is_admin TINYINT(1) NOT NULL DEFAULT 0,
    phone VARCHAR(20) NOT NULL DEFAULT ''
);

-- -----------------------------------------------------------
-- 2. ГРУППЫ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_group (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    min_age INT NOT NULL,
    max_age INT NOT NULL,
    capacity INT NOT NULL,
    description LONGTEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL
);

-- -----------------------------------------------------------
-- 3. СОТРУДНИКИ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_employee (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) NOT NULL DEFAULT '',
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(254) NOT NULL DEFAULT '',
    position VARCHAR(50) NOT NULL,
    hire_date DATE NOT NULL,
    salary DECIMAL(10,2) NOT NULL,
    address LONGTEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    photo VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES kids_user(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 4. ДЕТИ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_child (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) NOT NULL DEFAULT '',
    date_of_birth DATE NOT NULL,
    gender VARCHAR(1) NOT NULL,
    address LONGTEXT NOT NULL,
    parent_name VARCHAR(200) NOT NULL,
    parent_phone VARCHAR(20) NOT NULL,
    parent_email VARCHAR(254) NOT NULL DEFAULT '',
    parent_work VARCHAR(200) NOT NULL DEFAULT '',
    enrollment_date DATE NOT NULL,
    medical_notes LONGTEXT NOT NULL,
    allergies LONGTEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    photo VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL
);

-- -----------------------------------------------------------
-- 5. СОСТАВ ГРУППЫ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_groupmembership (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    child_id BIGINT NOT NULL,
    group_id BIGINT NOT NULL,
    date_from DATE NOT NULL,
    date_to DATE NULL,
    notes LONGTEXT NOT NULL,
    FOREIGN KEY (child_id) REFERENCES kids_child(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES kids_group(id) ON DELETE CASCADE
);

-- -----------------------------------------------------------
-- 6. ПОСЕЩАЕМОСТЬ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_attendance (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    child_id BIGINT NOT NULL,
    date DATE NOT NULL,
    status VARCHAR(20) NOT NULL,
    check_in_time TIME NULL,
    check_out_time TIME NULL,
    temperature DECIMAL(4,1) NULL,
    notes LONGTEXT NOT NULL,
    marked_by_id BIGINT NULL,
    created_at DATETIME(6) NOT NULL,
    UNIQUE KEY unique_attendance (child_id, date),
    FOREIGN KEY (child_id) REFERENCES kids_child(id) ON DELETE CASCADE,
    FOREIGN KEY (marked_by_id) REFERENCES kids_employee(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 7. ТИПЫ ЗАНЯТИЙ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_lessontype (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description LONGTEXT NOT NULL,
    duration_minutes INT NOT NULL,
    min_age INT NOT NULL DEFAULT 0,
    max_age INT NOT NULL DEFAULT 999,
    is_active TINYINT(1) NOT NULL DEFAULT 1
);

-- -----------------------------------------------------------
-- 8. РАСПИСАНИЕ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_schedule (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    group_id BIGINT NOT NULL,
    lesson_type_id BIGINT NOT NULL,
    day_of_week INT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    teacher_id BIGINT NULL,
    room VARCHAR(50) NOT NULL DEFAULT '',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (group_id) REFERENCES kids_group(id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_type_id) REFERENCES kids_lessontype(id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES kids_employee(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 9. ПРОВЕДЁННЫЕ ЗАНЯТИЯ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_lesson (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    group_id BIGINT NOT NULL,
    lesson_type_id BIGINT NOT NULL,
    schedule_id BIGINT NULL,
    teacher_id BIGINT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    topic VARCHAR(200) NOT NULL DEFAULT '',
    notes LONGTEXT NOT NULL,
    created_at DATETIME(6) NOT NULL,
    FOREIGN KEY (group_id) REFERENCES kids_group(id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_type_id) REFERENCES kids_lessontype(id) ON DELETE CASCADE,
    FOREIGN KEY (schedule_id) REFERENCES kids_schedule(id) ON DELETE SET NULL,
    FOREIGN KEY (teacher_id) REFERENCES kids_employee(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 10. ПЛАТЕЖИ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_payment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    child_id BIGINT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_for_month DATE NOT NULL,
    payment_method VARCHAR(20) NOT NULL DEFAULT 'cash',
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    receipt_number VARCHAR(50) NOT NULL DEFAULT '',
    notes LONGTEXT NOT NULL,
    created_by_id BIGINT NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    FOREIGN KEY (child_id) REFERENCES kids_child(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by_id) REFERENCES kids_employee(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 11. РАСХОДЫ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_expense (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    expense_date DATE NOT NULL,
    category VARCHAR(50) NOT NULL,
    description LONGTEXT NOT NULL,
    created_by_id BIGINT NULL,
    created_at DATETIME(6) NOT NULL,
    FOREIGN KEY (created_by_id) REFERENCES kids_employee(id) ON DELETE SET NULL
);

-- -----------------------------------------------------------
-- 12. МЕДИЦИНСКИЕ ЗАПИСИ
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS kids_medicalrecord (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    child_id BIGINT NOT NULL,
    record_date DATE NOT NULL,
    record_type VARCHAR(30) NOT NULL,
    description LONGTEXT NOT NULL,
    doctor_name VARCHAR(200) NOT NULL DEFAULT '',
    created_at DATETIME(6) NOT NULL,
    FOREIGN KEY (child_id) REFERENCES kids_child(id) ON DELETE CASCADE
);

-- ============================================================
-- ТЕСТОВЫЕ ДАННЫЕ
-- ============================================================

-- Администратор (пароль: admin123)
INSERT INTO kids_user (password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, is_employee, is_admin, phone)
VALUES ('pbkdf2_sha256$600000$dummyhash$dummyhashvalue', NULL, 1, 'admin', 'Администратор', 'Системы', 'admin@raduga.ru', 1, 1, NOW(), 0, 1, '+7(999)999-99-99');

-- Группы
INSERT INTO kids_group (name, min_age, max_age, capacity, description, is_active, created_at, updated_at) VALUES
('Ясельная', 12, 24, 12, 'Группа для самых маленьких (1-2 года)', 1, NOW(), NOW()),
('Младшая', 24, 36, 15, 'Младшая группа (2-3 года)', 1, NOW(), NOW()),
('Средняя', 36, 60, 18, 'Средняя группа (3-5 лет)', 1, NOW(), NOW()),
('Старшая', 60, 84, 18, 'Старшая группа (5-7 лет)', 1, NOW(), NOW()),
('Подготовительная', 72, 84, 15, 'Подготовка к школе (6-7 лет)', 1, NOW(), NOW());

-- Сотрудники
INSERT INTO kids_employee (user_id, first_name, last_name, middle_name, phone, email, position, hire_date, salary, address, is_active, created_at, updated_at) VALUES
(NULL, 'Елена', 'Иванова', 'Петровна', '+7(901)111-11-11', 'elena@raduga.ru', 'director', '2020-01-15', 85000.00, 'г. Москва, ул. Садовая, д.1', 1, NOW(), NOW()),
(NULL, 'Ольга', 'Смирнова', 'Алексеевна', '+7(902)222-22-22', 'olga@raduga.ru', 'methodist', '2020-02-01', 65000.00, 'г. Москва, ул. Цветочная, д.5', 1, NOW(), NOW()),
(NULL, 'Мария', 'Кузнецова', 'Сергеевна', '+7(903)333-33-33', 'maria@raduga.ru', 'teacher', '2021-03-01', 55000.00, 'г. Москва, ул. Лесная, д.10', 1, NOW(), NOW()),
(NULL, 'Анна', 'Попова', 'Дмитриевна', '+7(904)444-44-44', 'anna@raduga.ru', 'teacher', '2021-04-01', 55000.00, 'г. Москва, ул. Парковая, д.3', 1, NOW(), NOW()),
(NULL, 'Наталья', 'Васильева', 'Игоревна', '+7(905)555-55-55', 'natalia@raduga.ru', 'assistant', '2022-01-10', 35000.00, 'г. Москва, ул. Новая, д.7', 1, NOW(), NOW()),
(NULL, 'Ирина', 'Морозова', 'Викторовна', '+7(906)666-66-66', 'irina@raduga.ru', 'psychologist', '2021-09-01', 60000.00, 'г. Москва, ул. Солнечная, д.12', 1, NOW(), NOW()),
(NULL, 'Татьяна', 'Волкова', 'Андреевна', '+7(907)777-77-77', 'tatiana@raduga.ru', 'nurse', '2020-06-01', 50000.00, 'г. Москва, ул. Речная, д.8', 1, NOW(), NOW()),
(NULL, 'Светлана', 'Зайцева', 'Павловна', '+7(908)888-88-88', 'svetlana@raduga.ru', 'cook', '2020-03-01', 40000.00, 'г. Москва, ул. Зелёная, д.15', 1, NOW(), NOW()),
(NULL, 'Екатерина', 'Белова', 'Николаевна', '+7(909)999-99-99', 'ekaterina@raduga.ru', 'teacher', '2022-09-01', 50000.00, 'г. Москва, ул. Широкая, д.20', 1, NOW(), NOW()),
(NULL, 'Дмитрий', 'Соколов', 'Олегович', '+7(910)000-00-00', 'dmitry@raduga.ru', 'guard', '2023-01-15', 30000.00, 'г. Москва, ул. Дальняя, д.1', 1, NOW(), NOW());

-- Дети
INSERT INTO kids_child (first_name, last_name, middle_name, date_of_birth, gender, address, parent_name, parent_phone, parent_email, parent_work, enrollment_date, medical_notes, allergies, is_active, created_at, updated_at) VALUES
('Иван', 'Петров', 'Алексеевич', '2022-03-15', 'M', 'г. Москва, ул. Садовая, д.1', 'Петров Алексей Иванович', '+7(911)111-11-11', 'alexey@mail.ru', 'ООО "Ромашка"', '2023-09-01', '', '', 1, NOW(), NOW()),
('Мария', 'Сидорова', 'Ивановна', '2021-08-22', 'F', 'г. Москва, ул. Цветочная, д.5', 'Сидорова Елена Павловна', '+7(912)222-22-22', 'elena@mail.ru', 'Бухгалтерия №1', '2023-09-01', 'Наблюдение у аллерголога', 'Пыльца берёзы', 1, NOW(), NOW()),
('Артём', 'Козлов', 'Дмитриевич', '2020-05-10', 'M', 'г. Москва, ул. Лесная, д.10', 'Козлов Дмитрий Сергеевич', '+7(913)333-33-33', 'dmitry.kozlov@mail.ru', 'Сбербанк', '2022-09-01', '', '', 1, NOW(), NOW()),
('София', 'Новикова', 'Андреевна', '2019-11-28', 'F', 'г. Москва, ул. Парковая, д.3', 'Новикова Ольга Викторовна', '+7(914)444-44-44', 'olga.novikova@mail.ru', 'Гимназия №5', '2022-09-01', '', '', 1, NOW(), NOW()),
('Максим', 'Фёдоров', 'Антонович', '2023-01-05', 'M', 'г. Москва, ул. Новая, д.7', 'Фёдоров Антон Павлович', '+7(915)555-55-55', 'anton@mail.ru', 'ИТ-Компания', '2024-01-15', '', '', 1, NOW(), NOW()),
('Алиса', 'Морозова', 'Владимировна', '2022-07-14', 'F', 'г. Москва, ул. Солнечная, д.12', 'Морозова Екатерина Андреевна', '+7(916)666-66-66', 'ekaterina.m@mail.ru', 'Домохозяйка', '2023-09-01', 'Аллергия на молочные продукты', 'Лактоза', 1, NOW(), NOW()),
('Даниил', 'Григорьев', 'Павлович', '2020-12-03', 'M', 'г. Москва, ул. Речная, д.8', 'Григорьев Павел Сергеевич', '+7(917)777-77-77', 'pavel.g@mail.ru', 'Автосервис', '2022-09-01', '', '', 1, NOW(), NOW()),
('Виктория', 'Павлова', 'Денисовна', '2019-04-18', 'F', 'г. Москва, ул. Зелёная, д.15', 'Павлова Анна Михайловна', '+7(918)888-88-88', 'anna.pavlova@mail.ru', 'Поликлиника №3', '2021-09-01', '', '', 1, NOW(), NOW()),
('Тимофей', 'Александров', 'Романович', '2022-09-20', 'M', 'г. Москва, ул. Широкая, д.20', 'Александров Роман Игоревич', '+7(919)999-99-99', 'roman.a@mail.ru', 'ООО "СтройГарант"', '2024-02-01', '', '', 1, NOW(), NOW()),
('Ева', 'Крылова', 'Максимовна', '2021-06-12', 'F', 'г. Москва, ул. Дальняя, д.1', 'Крылова Наталья Сергеевна', '+7(920)000-00-00', 'natalia.k@mail.ru', 'Школа №7', '2023-09-01', '', 'Клубника', 1, NOW(), NOW()),
('Михаил', 'Тарасов', 'Олегович', '2020-10-30', 'M', 'г. Москва, ул. Садовая, д.15', 'Тарасов Олег Владимирович', '+7(921)111-11-11', 'oleg.t@mail.ru', 'Такси', '2023-01-15', '', '', 1, NOW(), NOW()),
('Арина', 'Беляева', 'Станиславовна', '2019-02-14', 'F', 'г. Москва, ул. Цветочная, д.8', 'Беляева Ирина Дмитриевна', '+7(922)222-22-22', 'irina.b@mail.ru', 'Банк ВТБ', '2022-09-01', '', '', 1, NOW(), NOW());

-- Состав групп
INSERT INTO kids_groupmembership (child_id, group_id, date_from, date_to, notes) VALUES
(5, 1, '2024-01-15', NULL, 'Ясельная группа'),
(9, 1, '2024-02-01', NULL, 'Ясельная группа'),
(2, 2, '2023-09-01', NULL, 'Младшая группа'),
(6, 2, '2023-09-01', NULL, 'Младшая группа'),
(10, 2, '2023-09-01', NULL, 'Младшая группа'),
(1, 3, '2023-09-01', NULL, 'Средняя группа'),
(3, 3, '2022-09-01', NULL, 'Средняя группа'),
(7, 3, '2022-09-01', NULL, 'Средняя группа'),
(11, 3, '2023-01-15', NULL, 'Средняя группа'),
(4, 4, '2022-09-01', NULL, 'Старшая группа'),
(8, 4, '2021-09-01', NULL, 'Старшая группа'),
(12, 4, '2022-09-01', NULL, 'Старшая группа');

-- Типы занятий
INSERT INTO kids_lessontype (name, description, duration_minutes, min_age, max_age, is_active) VALUES
('Рисование', 'Занятия изобразительным искусством', 30, 24, 84, 1),
('Лепка', 'Лепка из пластилина и глины', 30, 24, 84, 1),
('Физкультура', 'Физические упражнения и игры', 30, 12, 84, 1),
('Музыка', 'Музыкальные занятия и пение', 30, 12, 84, 1),
('Развитие речи', 'Занятия по развитию речи', 30, 24, 84, 1),
('Математика', 'Основы математики и счёта', 30, 36, 84, 1),
('Английский язык', 'Изучение английского языка', 25, 48, 84, 1),
('Чтение', 'Обучение чтению', 30, 60, 84, 1),
('Окружающий мир', 'Изучение окружающего мира', 30, 36, 84, 1),
('Танцы', 'Хореография и ритмика', 30, 36, 84, 1);

-- Расписание (для средней группы, группа 3)
INSERT INTO kids_schedule (group_id, lesson_type_id, day_of_week, start_time, end_time, teacher_id, room, is_active) VALUES
(3, 1, 1, '09:00:00', '09:30:00', 3, 'Каб. рисования', 1),
(3, 4, 1, '10:00:00', '10:30:00', 4, 'Муз. зал', 1),
(3, 3, 2, '09:00:00', '09:30:00', 3, 'Спортзал', 1),
(3, 5, 2, '10:00:00', '10:30:00', 4, 'Каб. 3', 1),
(3, 2, 3, '09:00:00', '09:30:00', 3, 'Каб. 3', 1),
(3, 6, 3, '10:00:00', '10:30:00', 4, 'Каб. 3', 1),
(3, 4, 4, '09:00:00', '09:30:00', 4, 'Муз. зал', 1),
(3, 9, 4, '10:00:00', '10:30:00', 3, 'Каб. 3', 1),
(3, 3, 5, '09:00:00', '09:30:00', 3, 'Спортзал', 1),
(3, 1, 5, '10:00:00', '10:30:00', 4, 'Каб. рисования', 1);

-- Проведённые занятия
INSERT INTO kids_lesson (group_id, lesson_type_id, schedule_id, teacher_id, date, start_time, end_time, topic, notes, created_at) VALUES
(3, 1, 1, 3, '2025-05-19', '09:00:00', '09:30:00', 'Весенние цветы', '', NOW()),
(3, 4, 2, 4, '2025-05-19', '10:00:00', '10:30:00', 'Песни о весне', '', NOW()),
(3, 3, 3, 3, '2025-05-13', '09:00:00', '09:30:00', 'Эстафеты', '', NOW()),
(3, 5, 4, 4, '2025-05-13', '10:00:00', '10:30:00', 'Времена года', '', NOW());

-- Платежи
INSERT INTO kids_payment (child_id, amount, payment_date, payment_for_month, payment_method, status, receipt_number, notes, created_by_id, created_at, updated_at) VALUES
(1, 35000.00, '2025-05-01', '2025-05-01', 'card', 'paid', 'REC-2025-001', 'Оплата май 2025', 1, NOW(), NOW()),
(2, 35000.00, '2025-04-28', '2025-05-01', 'cash', 'paid', 'REC-2025-002', '', 1, NOW(), NOW()),
(3, 35000.00, '2025-05-05', '2025-05-01', 'transfer', 'paid', 'REC-2025-003', '', 1, NOW(), NOW()),
(4, 35000.00, '2025-05-01', '2025-05-01', 'online', 'paid', 'REC-2025-004', '', 1, NOW(), NOW()),
(5, 40000.00, '2025-05-02', '2025-05-01', 'card', 'paid', 'REC-2025-005', '', 1, NOW(), NOW()),
(6, 35000.00, '2025-04-25', '2025-05-01', 'cash', 'paid', 'REC-2025-006', 'Оплачено досрочно', 1, NOW(), NOW()),
(7, 35000.00, '2025-05-10', '2025-05-01', 'card', 'pending', '', 'Ожидает подтверждения', 1, NOW(), NOW()),
(8, 35000.00, '2025-05-01', '2025-05-01', 'online', 'paid', 'REC-2025-007', '', 1, NOW(), NOW()),
(9, 40000.00, '2025-05-01', '2025-05-01', 'card', 'paid', 'REC-2025-008', '', 1, NOW(), NOW()),
(10, 35000.00, '2025-05-03', '2025-05-01', 'cash', 'paid', 'REC-2025-009', '', 1, NOW(), NOW()),
(11, 35000.00, '2025-04-15', '2025-05-01', 'transfer', 'paid', 'REC-2025-010', '', 1, NOW(), NOW()),
(12, 35000.00, '2025-05-05', '2025-05-01', 'card', 'pending', '', 'Ожидает', 1, NOW(), NOW());

-- Расходы
INSERT INTO kids_expense (title, amount, expense_date, category, description, created_by_id, created_at) VALUES
('Закупка продуктов', 15000.00, '2025-05-05', 'food', 'Продукты на неделю', 1, NOW()),
('Зарплата мая', 470000.00, '2025-05-10', 'salary', 'Зарплата сотрудникам за май', 1, NOW()),
('Электроэнергия', 8500.00, '2025-05-12', 'utilities', 'Квитанция за апрель', 1, NOW()),
('Новые игрушки', 12000.00, '2025-05-08', 'toys', 'Конструкторы и куклы', 1, NOW()),
('Канцтовары', 3400.00, '2025-05-06', 'other', 'Бумага, краски, карандаши', 1, NOW()),
('Ремонт крана', 2500.00, '2025-05-04', 'repair', 'Замена смесителя в ясельной группе', 1, NOW());

-- Медицинские записи
INSERT INTO kids_medicalrecord (child_id, record_date, record_type, description, doctor_name, created_at) VALUES
(2, '2024-09-15', 'allergy', 'Выявлена аллергия на пыльцу берёзы', 'Петрова А.И.', NOW()),
(6, '2024-10-01', 'allergy', 'Аллергия на лактозу, назначена диета', 'Петрова А.И.', NOW()),
(2, '2024-11-20', 'vaccination', 'Прививка АКДС', 'Иванова М.С.', NOW()),
(1, '2025-01-15', 'examination', 'Плановый осмотр, здоров', 'Петрова А.И.', NOW()),
(3, '2024-12-10', 'illness', 'ОРВИ, лёгкая форма', 'Иванова М.С.', NOW()),
(10, '2025-03-01', 'allergy', 'Аллергия на клубнику', 'Петрова А.И.', NOW());
